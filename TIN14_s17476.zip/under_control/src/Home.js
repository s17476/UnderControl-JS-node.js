import React, { Component } from 'react';
import './Home.css';

class Home extends Component {

    render() {
        return (
            <div className="Body">
                <h1 className="header">Welcome<br/>Home screen...</h1>
            </div>
        );
    }
}

export default Home;