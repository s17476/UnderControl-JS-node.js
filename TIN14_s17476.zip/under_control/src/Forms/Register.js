import React, { Component } from 'react';


class Register extends Component {



    render() {
        return (
            <div className="App">
                Hello
            </div>
        );
    }
}

export default Register;
