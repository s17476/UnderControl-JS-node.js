import React, { Component } from 'react';
import './NotFound.css';

class NotFound extends Component {

    render() {
        return (
            <div className="Body">
                <h1 className="header">OOOPS!<br/>Something went wrong...</h1>
            </div>
        );
    }
}

export default NotFound;