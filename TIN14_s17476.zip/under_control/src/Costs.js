import React, { Component } from 'react';
import './Costs.css';

class Costs extends Component {

    render() {
        return (
            <div className="Body">
                <h1 className="header">Costs<br/>costs screen...</h1>
            </div>
        );
    }
}

export default Costs;