import React, { Component } from 'react';
import './Accessibility.css';

class Accessibility extends Component {

    render() {
        return (
            <div className="Body">
                <h1 className="header">Accessibility<br/>Accessibility</h1>
            </div>
        );
    }
}

export default Accessibility;