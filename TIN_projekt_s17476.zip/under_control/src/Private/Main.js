import React, { Component } from 'react';


class Main extends Component {

    render() {
        return (
            <div className="Body">
                <p className="header">Main<br/>Page</p>
            </div>
        );
    }
}

export default Main;