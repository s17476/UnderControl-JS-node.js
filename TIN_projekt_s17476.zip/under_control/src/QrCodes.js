import React, { Component } from 'react';
import './QrCodes.css';

class QrCodes extends Component {

    render() {
        return (
            <div className="Body">
                <h1 className="header">QrCodes<br/>QrCodes screen...</h1>
            </div>
        );
    }
}

export default QrCodes;