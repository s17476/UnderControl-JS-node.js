import React, { Component } from 'react';
import logo from './logo.png';
import Login from "./Forms/Login";
import './App.css';
import {Link} from "react-router-dom";

class App extends Component {



    render() {
        return (
            <div className="App">
                <div className="Header">
                    <header className="App-header">
                        <img src={logo} className="App-logo" alt="logo" />
                        <h1 className="App-title">UnderControl</h1>
                        <p className="App-title-slogan">
                            - innovation in your hands
                        </p>
                    </header>
                </div>
                <div className="App-nav" id="navbar">
                    <Link className="App-nav-item" to="/home">Home</Link>
                    <Link className="App-nav-item" to="/costs">Costs</Link>
                    <Link className="App-nav-item" to="/accessibility">Accessibility</Link>
                    <Link className="App-nav-item" to="/qrCodes">QrCodes</Link>
                    <Login />

                </div>
                <div className="xxx">

                </div>
            </div>
        );
  }
}

export default App;
